// In-browser mock backend for `?mock=1` (owned by M6). Implements the subset of
// docs/api.md + docs/api-envs.md that the UI uses, with plausible fake data,
// so the desktop UI can be developed and screenshot-tested without a server.
const enc = new TextEncoder();
const now = () => new Date().toISOString();
const ago = (s) => new Date(Date.now() - s * 1000).toISOString();
let seq = 100;
const uid = (p) => p + '-' + (++seq).toString(36) + Math.random().toString(36).slice(2, 6);
const clone = (x) => JSON.parse(JSON.stringify(x));

// ---------- providers ----------
const C = { L: 'lifecycle', X: 'exec', F: 'files', V: 'desktop.vnc', S: 'desktop.screen', M: 'metrics', A: 'agents', I: 'install-agentos' };
const providers = [
  { type: 'agentos-local', name: '本机 Agent OS 实例', kind: 'agentos', group: 'Agent OS', description: '在本机启动一个独立的 Agent OS 实例（独立数据目录与端口），适合隔离不同项目的智能体。',
    capabilities: [C.L, C.X, C.F, C.S, C.M, C.A],
    config_schema: { type: 'object', properties: {
      port: { type: 'integer', title: '端口', default: 7801, minimum: 1024, maximum: 65535 },
      data_dir: { type: 'string', title: '数据目录', description: '留空使用默认目录' },
      autostart: { type: 'boolean', title: '随 AgentOS 自动启动', default: true } } } },
  { type: 'agentos-remote', name: '远程 Agent OS', kind: 'agentos', group: 'Agent OS', description: '登记一台远程机器：在目标机器上运行加入命令，节点会自动连接回来。',
    capabilities: [C.X, C.F, C.V, C.S, C.M, C.A],
    config_schema: { type: 'object', properties: {
      os: { type: 'string', title: '目标系统', enum: ['windows', 'linux', 'macos'], default: 'windows' },
      note: { type: 'string', title: '备注' } } } },
  { type: 'docker', name: 'Docker 容器', kind: 'container', group: '容器', description: '使用 Docker 创建隔离容器环境，可一键安装 Agent OS 获得完整的智能体托管能力。',
    capabilities: [C.L, C.X, C.F, C.M, C.I],
    config_schema: { type: 'object', required: ['image'], properties: {
      host: { type: 'string', title: 'Docker 主机', default: 'unix:///var/run/docker.sock' },
      image: { type: 'string', title: '镜像', default: 'ubuntu:24.04' },
      cpus: { type: 'number', title: 'CPU 核数', default: 2, minimum: 0.5 },
      memory_mb: { type: 'integer', title: '内存 (MB)', default: 4096 },
      network: { type: 'string', title: '网络', enum: ['bridge', 'host', 'none'], default: 'bridge' },
      ports: { type: 'array', title: '端口映射', items: { type: 'string' }, description: '例如 8080:80' },
      privileged: { type: 'boolean', title: '特权模式', default: false } } } },
  { type: 'hyperv', name: '本机虚拟机（Hyper-V）', kind: 'vm', group: '本机虚拟机', description: '在本机 Hyper-V 创建 Linux/Windows 桌面虚拟机。', capabilities: ['lifecycle', 'desktop.vnc', 'metrics'],
    config_schema: { type: 'object', properties: {
      guest_os: { type: 'string', title: '客户机系统', enum: ['ubuntu-24.04', 'windows-11', 'fedora-workstation', 'custom'], default: 'ubuntu-24.04' },
      cpus: { type: 'integer', title: 'vCPU', default: 8 }, memory_mb: { type: 'integer', title: '内存 (MB)', default: 16384 },
      disk_gb: { type: 'integer', title: '磁盘 (GB)', default: 80 }, iso_path: { type: 'string', title: 'ISO 路径' } } } },
  { type: 'ssh', name: 'SSH 服务器 / 虚拟机', kind: 'vm', group: '虚拟机', description: '通过 SSH 连接已有的 Linux / Windows 服务器或虚拟机。',
    capabilities: [C.X, C.F, C.M, C.I],
    config_schema: { type: 'object', required: ['host', 'user'], properties: {
      host: { type: 'string', title: '主机地址' }, port: { type: 'integer', title: '端口', default: 22 },
      user: { type: 'string', title: '用户名', default: 'root' },
      auth: { type: 'string', title: '认证方式', enum: ['password', 'key'], default: 'key' },
      password: { type: 'string', title: '密码', 'x-secret': true },
      private_key: { type: 'string', title: '私钥', 'x-secret': true, format: 'textarea' } } } },
  { type: 'e2b', name: 'E2B 云沙箱', kind: 'sandbox', group: '云沙箱', description: '在 E2B 云端按需创建沙箱（预览）。',
    capabilities: [C.L, C.X, C.F],
    config_schema: { type: 'object', required: ['api_key'], properties: {
      api_key: { type: 'string', title: 'API Key', 'x-secret': true }, template: { type: 'string', title: '模板', default: 'base' } } } },
];
const pinfo = (t) => { const p = providers.find((x) => x.type === t) || { type: t, name: t, group: '其他', kind: 'vm', capabilities: [] }; return { type: p.type, name: p.name, group: p.group, kind: p.kind }; };
const pcaps = (t) => (providers.find((x) => x.type === t)?.capabilities || []);

// ---------- environments ----------
const envs = [
  { id: 'local', name: '本机', provider: 'agentos-local', config: { port: 7800 }, node_id: 'node-local', labels: { builtin: 'true' }, state: 'running', address: '127.0.0.1', created_at: ago(86400 * 12) },
  { id: 'env-proj-b', name: '项目B 隔离实例', provider: 'agentos-local', config: { port: 7802, autostart: false }, node_id: 'node-projb', state: 'stopped', address: '127.0.0.1:7802', created_at: ago(86400 * 3) },
  { id: 'env-gpu', name: 'gpu-server-01', provider: 'agentos-remote', config: { os: 'linux', note: '机房 A3' }, node_id: 'node-gpu', labels: { gpu: 'rtx4090', site: 'A3' }, state: 'running', address: '10.0.3.21', created_at: ago(86400 * 30) },
  { id: 'env-win', name: '设计部-WIN11', provider: 'agentos-remote', config: { os: 'windows' }, node_id: 'node-win', state: 'unknown', address: '192.168.1.57', created_at: ago(86400 * 7), message: '节点离线 2 小时' },
  { id: 'env-py', name: 'py-sandbox', provider: 'docker', config: { image: 'python:3.12-slim', cpus: 2, memory_mb: 4096, network: 'bridge', host: 'unix:///var/run/docker.sock' }, state: 'running', address: '172.17.0.4', created_at: ago(3600 * 5), stack: 'python' },
  { id: 'env-ubuntu', name: 'ubuntu-agents', provider: 'docker', config: { image: 'ubuntu:24.04', cpus: 4, memory_mb: 8192 }, node_id: 'node-docker', state: 'running', address: '172.17.0.7', created_at: ago(86400), stack: 'node' },
  { id: 'env-vm', name: 'build-vm', provider: 'ssh', config: { host: '10.0.5.12', port: 22, user: 'ci', auth: 'key' }, secrets_set: ['private_key'], state: 'error', error: 'ssh: handshake failed: unable to authenticate, attempted methods [none publickey]', address: '10.0.5.12', created_at: ago(86400 * 2) },
  { id: 'env-e2b', name: 'e2b-scratch', provider: 'e2b', config: { template: 'base' }, state: 'creating', created_at: ago(40) },
];
const envView = (e) => ({ id: e.id, name: e.name, provider: e.provider, config: e.config, stack: e.stack, node_id: e.node_id, labels: e.labels || {},
  state: e.state, error: e.error, created_at: e.created_at, updated_at: e.updated_at || e.created_at,
  status: { state: e.state, message: e.message || e.error || '', address: e.address || '' },
  capabilities: (e.node_id && !pcaps(e.provider).includes(C.A) ? [...pcaps(e.provider).filter((c) => c !== C.I), C.A, C.S] : pcaps(e.provider)).filter((c) => !(e.labels?.builtin && c === C.L)),
  secrets_set: e.secrets_set || [], busy: e.busy || undefined,
  provider_info: pinfo(e.provider) });
const envLogs = {};
const elog = (id, level, text) => { (envLogs[id] = envLogs[id] || []).push({ t: now(), level, text }); broadcast('env.log', { id, t: now(), level, text }); };
for (const e of envs) envLogs[e.id] = [
  { t: e.created_at, level: 'info', text: `创建环境 ${e.name} (${e.provider})` },
  { t: e.created_at, level: 'info', text: e.provider === 'docker' ? `docker pull ${e.config.image}` : 'provisioning…' },
  ...(e.state === 'error' ? [{ t: ago(60), level: 'error', text: e.error }] : [{ t: ago(30), level: 'info', text: '环境就绪 / ready' }]),
];

// ---------- nodes / agents ----------
const nodes = envs.filter((e) => e.node_id).map((e) => ({ id: e.node_id, name: e.name, hostname: e.name.toLowerCase(), os: e.config.os === 'windows' ? 'windows' : 'linux', arch: 'amd64', version: '0.2.0', status: ['running'].includes(e.state) ? 'online' : 'offline',
  capabilities: ['stats', 'desktop.screen'], last_seen: ago(120), created_at: e.created_at, remote_addr: e.address }));
const ag = (id, node, name, cmd, args, state, extra = {}) => ({ id, node_id: node, name, command: cmd, args, env: extra.env || {}, restart: extra.restart || 'on-failure', max_restarts: 0, restart_delay_sec: 3, auto_start: !!extra.auto,
  description: extra.desc || '', created_at: ago(86400), updated_at: ago(3600),
  status: { id, node_id: node, state, pid: state === 'running' ? 1000 + Math.floor(Math.random() * 30000) : 0, restarts: extra.restarts || 0, started_at: state === 'running' ? ago(extra.up || 3600) : undefined,
    exit_code: state === 'failed' ? 1 : state === 'exited' ? 0 : undefined, error: state === 'failed' ? 'exit status 1' : '', workspace: `/var/lib/agentos/agents/${id}/workspace`, updated_at: now() } });
const agents = [
  ag('ag-research', 'node-local', 'research-bot', 'python3', ['-u', 'main.py', '--topic', 'LLM agents'], 'running', { desc: '每小时抓取并总结论文', env: { OPENAI_API_KEY: 'sk-xxx', PYTHONUNBUFFERED: '1' }, up: 7400 }),
  ag('ag-claude', 'node-local', 'claude-refactor', 'claude', ['-p', '重构 src/ 下的日志模块', '--output-format', 'stream-json'], 'running', { desc: 'Claude Code 无头任务', up: 640 }),
  ag('ag-crawler', 'node-gpu', 'crawler-01', 'node', ['crawler.js'], 'running', { up: 86400 * 2 + 300, restarts: 2 }),
  ag('ag-train', 'node-gpu', 'lora-train', 'python3', ['train.py', '--epochs', '3'], 'failed', { restart: 'never' }),
  ag('ag-win', 'node-win', 'office-assistant', 'powershell', ['-File', 'assist.ps1'], 'unknown'),
  ag('ag-codex', 'node-docker', 'codex-worker', 'codex', ['exec', '--full-auto', '修复失败的单元测试'], 'stopped', { restart: 'never' }),
  ag('ag-cron', 'node-docker', 'nightly-report', 'sh', ['-c', 'python report.py && sleep 86400'], 'exited', { restart: 'always' }),
];
const agentLogs = {};
const LOGTXT = ['\x1b[36m[info]\x1b[0m loading config from ./config.yaml', '\x1b[32m✓\x1b[0m connected to model endpoint (latency 182 ms)',
  'fetching https://arxiv.org/list/cs.AI/recent …', '\x1b[33m[warn]\x1b[0m rate limited, retrying in 2s', 'processed 24 items, 3 new',
  '\x1b[1;34mstep\x1b[0m 1/5 analysing repository structure', 'writing summary to out/summary-2026-10-10.md', '\x1b[31m[error]\x1b[0m tool call failed: timeout after 30s'];
function genLog(id, n) {
  const arr = agentLogs[id] = agentLogs[id] || [];
  for (let i = 0; i < n; i++) arr.push({ agent_id: id, seq: arr.length + 1, time: ago(n - i), stream: i % 9 === 0 ? 'stderr' : i === 0 ? 'system' : 'stdout', text: i === 0 ? '进程已启动 / started' : LOGTXT[(arr.length + i) % LOGTXT.length] });
  return arr;
}
for (const a of agents) genLog(a.id, 60);

// ---------- stacks ----------
const svg = (txt, color) => `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><rect width="24" height="24" rx="5" fill="${color}"/><text x="12" y="16" font-family="Segoe UI,Arial" font-size="${txt.length > 1 ? 10 : 13}" font-weight="700" text-anchor="middle" fill="#fff">${txt}</text></svg>`;
const st = (id, name, name_en, cat, mono, color, desc, desc_en, langs, tpls, env_vars = []) => ({ id, name, name_en, category: cat, icon: id, icon_svg: svg(mono, color), color, description: desc, description_en: desc_en,
  languages: langs, homepage: 'https://example.com/' + id, setup: { linux: [['sh', '-c', 'echo install ' + id]] }, detect: ['sh', '-c', id + ' --version'], env_vars, agent_templates: tpls });
const stacks = [
  st('python', 'Python', 'Python', 'runtime', 'Py', '#3776ab', 'Python 3 运行时 + pip/uv，适合数据处理与 LLM 应用。', 'Python 3 runtime with pip/uv.', ['python'],
    [{ id: 'python-script', name: 'Python 脚本', name_en: 'Python script', command: ['python3', '-u', 'main.py'], command_windows: ['python', '-u', 'main.py'], env: { PYTHONUNBUFFERED: '1' } }]),
  st('node', 'Node.js', 'Node.js', 'runtime', 'JS', '#3c873a', 'Node.js LTS + npm/pnpm。', 'Node.js LTS with npm/pnpm.', ['javascript', 'typescript'],
    [{ id: 'node-script', name: 'Node 脚本', name_en: 'Node script', command: ['node', 'index.js'] }]),
  st('go', 'Go', 'Go', 'runtime', 'Go', '#00add8', 'Go 工具链。', 'Go toolchain.', ['go'], []),
  st('claude-code', 'Claude Code', 'Claude Code', 'agent', 'C', '#d97757', 'Anthropic Claude Code CLI，无头模式执行编码任务。', 'Anthropic Claude Code CLI in headless mode.', ['cli'],
    [{ id: 'claude-task', name: 'Claude Code 任务', name_en: 'Claude Code task', command: ['claude', '-p', '在此描述任务', '--output-format', 'stream-json', '--verbose'], env: { ANTHROPIC_API_KEY: '${ANTHROPIC_API_KEY}' } }],
    [{ name: 'ANTHROPIC_API_KEY', description: 'Anthropic API key', secret: true, required: true }]),
  st('openai-codex-cli', 'OpenAI Codex CLI', 'OpenAI Codex CLI', 'agent', 'Cx', '#10a37f', 'Codex CLI 自动化编码代理。', 'Codex CLI coding agent.', ['cli'],
    [{ id: 'codex-exec', name: 'Codex 执行', name_en: 'Codex exec', command: ['codex', 'exec', '--full-auto', '在此描述任务'], env: { OPENAI_API_KEY: '${OPENAI_API_KEY}' } }],
    [{ name: 'OPENAI_API_KEY', description: 'OpenAI API key', secret: true, required: true }]),
  st('aider', 'Aider', 'Aider', 'agent', 'Ai', '#14b8a6', 'Aider 结对编程助手。', 'Aider pair-programming assistant.', ['cli'], []),
];
const envStacks = { local: ['python', 'node', 'claude-code'], 'env-py': ['python'], 'env-ubuntu': ['node'] };

// ---------- files ----------
const files = { '/': [['home', 1], ['opt', 1], ['etc', 1], ['README.md', 0, 1820]], '/home': [['agent', 1]], '/home/agent': [['workspace', 1], ['.bashrc', 0, 3771], ['notes.txt', 0, 912]],
  '/home/agent/workspace': [['main.py', 0, 4210], ['requirements.txt', 0, 96], ['out', 1], ['config.yaml', 0, 512]], '/home/agent/workspace/out': [['summary-2026-10-10.md', 0, 18342]], '/opt': [['agentos', 1]], '/opt/agentos': [['agentos', 0, 28311552]], '/etc': [['hostname', 0, 12], ['os-release', 0, 386]] };
const fileContents = {};

// ---------- metrics ----------
function samples(id, n = 60) {
  const base = id.length * 7 % 40 + 10, out = [];
  for (let i = n; i > 0; i--) {
    const t = Date.now() - i * 5000, ph = (Date.now() / 5000 - i) / 6;
    out.push({ t: new Date(t).toISOString(), cpu_percent: Math.max(1, Math.min(99, base + 18 * Math.sin(ph + id.length) + 6 * Math.sin(ph * 3.1))), mem_total: 16 * 2 ** 30, mem_used: (6 + 2 * Math.sin(ph / 3)) * 2 ** 30, disk_total: 512 * 2 ** 30, disk_used: 201 * 2 ** 30 });
  }
  return out;
}

// ---------- event sockets ----------
const sockets = new Set();
function broadcast(type, payload) { for (const s of sockets) if (s.kind === 'events') s.recv(JSON.stringify({ type, time: now(), payload })); }

// ---------- REST ----------
class R { constructor(status, body, headers) { this.status = status; this.body = body; this.headers = headers; } }
const err = (status, msg, code) => new R(status, { error: msg, code });
let token = 'aos_mock_' + Math.random().toString(36).slice(2, 14);

const presets = [
  { id: 'agentos-desktop', provider: 'agentos-local', category: 'agentos', icon: 'agentos', name: '本机 Agent OS 实例（虚拟桌面）', name_en: 'Local Agent OS instance (virtual desktop)', description: '在本机启动一个独立的 Agent OS 实例，带自己的虚拟桌面。', base_name: 'Agent OS 实例', config: { desktop: 'virtual', auto_start: true }, tags: ['推荐', '智能体', '桌面'], available: true },
  { id: 'agentos-remote', provider: 'agentos-remote', category: 'agentos', icon: 'agentos-remote', name: '远程 Agent OS（加入另一台电脑）', name_en: 'Remote Agent OS', description: '登记另一台电脑：创建后显示加入命令。', base_name: '远程电脑', config: { desktop: 'host' }, tags: ['Windows', 'Linux', 'macOS'], available: true },
  { id: 'docker-desktop', provider: 'docker', category: 'container', icon: 'desktop', name: 'Ubuntu Desktop（容器）', name_en: 'Ubuntu Desktop (Docker)', description: 'Ubuntu 24.04 图形桌面容器，仅开通虚拟电脑。', base_name: 'Ubuntu 桌面', config: { desktop: true, cpus: 2, memory_mb: 4096 }, tags: ['推荐', '桌面', 'Ubuntu'], available: true },
  { id: 'docker-ubuntu-server', provider: 'docker', category: 'container', icon: 'docker', name: 'Ubuntu Server（Docker）', name_en: 'Ubuntu Server (Docker)', description: 'ubuntu:24.04 服务器容器。', base_name: 'Ubuntu 服务器', config: { image: 'ubuntu:24.04', cpus: 1, memory_mb: 2048 }, tags: ['Ubuntu', '服务器'], available: true },
  { id: 'docker-debian', provider: 'docker', category: 'container', icon: 'docker', name: 'Debian（Docker）', name_en: 'Debian (Docker)', description: 'debian:bookworm-slim。', base_name: 'Debian', config: { image: 'debian:bookworm-slim', cpus: 1, memory_mb: 1024 }, tags: ['Debian'], available: true },
  { id: 'docker-fedora', provider: 'docker', category: 'container', icon: 'docker', name: 'Fedora（Docker）', name_en: 'Fedora (Docker)', description: 'fedora:40。', base_name: 'Fedora', config: { image: 'fedora:40', cpus: 1, memory_mb: 2048 }, tags: ['Fedora'], available: true },
  { id: 'docker-python', provider: 'docker', category: 'container', icon: 'python', name: 'Python 3.12 沙箱镜像', name_en: 'Python 3.12 sandbox image', description: 'python:3.12-slim（不另装 AI 工具）。', base_name: 'Python 沙箱', config: { image: 'python:3.12-slim', cpus: 2, memory_mb: 2048 }, tags: ['Python', '沙箱'], available: true },
  { id: 'docker-node', provider: 'docker', category: 'container', icon: 'node', name: 'Node 22 沙箱镜像', name_en: 'Node 22 sandbox image', description: 'node:22（不另装 AI 工具）。', base_name: 'Node 沙箱', config: { image: 'node:22', cpus: 2, memory_mb: 2048 }, tags: ['Node.js', '沙箱'], available: true },
  { id: 'ssh-local', provider: 'ssh', category: 'ssh', icon: 'ssh', name: '本机 SSH', name_en: 'Local SSH', description: '通过 SSH 连接本机。', base_name: '本机 SSH', config: { host: '127.0.0.1', port: 22, user: 'admin', private_key_path: '~/.ssh/id_ed25519', host_key_policy: 'tofu' }, tags: ['终端', '文件'], available: false, reason: '本机未运行 SSH 服务（127.0.0.1:22）', note: '需运行 sshd 且公钥已授权。' },
  { id: 'hyperv-ubuntu-2404', provider: 'hyperv', category: 'vm', icon: 'desktop', name: '本地虚拟机 · Ubuntu 24.04 桌面', name_en: 'Local VM · Ubuntu 24.04 Desktop', description: 'Hyper-V Gen2（非容器），8 vCPU / 16 GB。', base_name: 'Ubuntu 本地虚拟机', config: { guest_os: 'ubuntu-24.04', cpus: 8, memory_mb: 16384, disk_gb: 80 }, tags: ['推荐', '本机虚拟机', 'Ubuntu'], available: false, reason: '未检测到 Hyper-V（模拟数据）', note: '与 Docker 容器不同：完整本机虚拟机。' },
  { id: 'hyperv-windows11', provider: 'hyperv', category: 'vm', icon: 'desktop', name: '本地虚拟机 · Windows 11 桌面', name_en: 'Local VM · Windows 11', description: '需自行提供评估版 ISO。', base_name: 'Windows 本地虚拟机', config: { guest_os: 'windows-11', cpus: 8, memory_mb: 16384, disk_gb: 100 }, tags: ['本机虚拟机', 'Windows'], available: false, reason: '未检测到 Hyper-V（模拟数据）' },
  { id: 'hyperv-macos', provider: 'hyperv', category: 'vm', icon: 'desktop', name: '本地虚拟机 · macOS（不可用）', name_en: 'Local VM · macOS', description: '需 Apple 主机。', base_name: 'macOS 虚拟机', config: { guest_os: 'macos' }, tags: ['macOS', '不可用'], available: false, reason: 'macOS 虚拟机需 Apple 主机（Apple Silicon / macOS 宿主）；当前 Windows 主机无法正版运行。' },
  { id: 'hyperv-fedora', provider: 'hyperv', category: 'vm', icon: 'desktop', name: '本地虚拟机 · Fedora Workstation（高级）', name_en: 'Local VM · Fedora', description: '可选高级预设。', base_name: 'Fedora 本地虚拟机', config: { guest_os: 'fedora-workstation', cpus: 8, memory_mb: 16384 }, tags: ['本机虚拟机', 'Fedora', '高级'], available: false, reason: '未检测到 Hyper-V（模拟数据）' },
  { id: 'virtualbox', provider: 'virtualbox', category: 'vm', icon: 'desktop', name: 'VirtualBox 虚拟机', name_en: 'VirtualBox VM', description: '尚未接入。', base_name: 'VirtualBox', config: {}, tags: ['即将支持'], available: false, reason: '未检测到 VirtualBox（VBoxManage）' },
];

function route(method, path, body) {
  const [p, qs] = path.split('?'); const q = new URLSearchParams(qs || ''); const seg = p.split('/').filter(Boolean);
  const M = (m, pat) => { if (m !== method) return null; const ps = pat.split('/').filter(Boolean); if (ps.length !== seg.length) return null; const o = {}; for (let i = 0; i < ps.length; i++) { if (ps[i][0] === ':') o[ps[i].slice(1)] = decodeURIComponent(seg[i]); else if (ps[i] !== seg[i]) return null; } return o; };
  let m;
  if (M('GET', '/health')) return { status: 'ok', version: '0.2.0-mock' };
  if (M('GET', '/version')) return { version: '0.2.0-mock', commit: 'mock', date: now(), protocol: 1 };
  if (M('POST', '/auth/login')) return body?.password ? { token: 'mock' } : err(401, 'invalid password', 'bad_credentials');
  if (M('POST', '/auth/logout')) return null;
  if (M('GET', '/auth/me')) return { authenticated: true, user: 'admin' };
  if (M('POST', '/auth/password')) return (body?.new_password || '').length < 6 ? err(400, 'password too short', 'bad_request') : null;
  if (M('GET', '/settings/node-token')) return { token };
  if (M('POST', '/settings/node-token/rotate')) { token = 'aos_mock_' + Math.random().toString(36).slice(2, 14); return { token }; }
  if (M('GET', '/providers')) return providers;
  if ((m = M('POST', '/providers/:type/test'))) {
    const pv = providers.find((x) => x.type === m.type); if (!pv) return err(404, 'unknown provider', 'not_found');
    const miss = (pv.config_schema.required || []).filter((k) => !body?.config?.[k]);
    if (miss.length) return err(400, 'missing required: ' + miss.join(', '), 'bad_request');
    if (m.type === 'ssh' && body.config.host === 'bad') return err(502, 'dial tcp: connection refused', 'node_error');
    return { ok: true };
  }
  if (M('GET', '/env-presets')) return presets;
  if (M('GET', '/tool-presets')) return stacks; // alias of /stacks
  if (M('GET', '/envs')) return envs.map(envView);
  if (M('POST', '/envs')) {
    body = { ...(body || {}) };
    if (body.preset) {
      const pr = presets.find((x) => x.id === body.preset); if (!pr) return err(400, 'unknown preset', 'bad_request');
      body.provider = pr.provider; body.config = { ...pr.config, ...(body.config || {}) }; body.name = body.name || pr.base_name;
      if (body.name === pr.base_name) { let i = 1; while (envs.some((e) => e.name === `${pr.base_name} ${i}`)) i++; body.name = `${pr.base_name} ${i}`; }
    }
    if (!body.name && body.provider) { const pv = providers.find((x) => x.type === body.provider); let i = 1; while (envs.some((e) => e.name === `${pv?.name} ${i}`)) i++; body.name = `${pv?.name || '环境'} ${i}`; }
    if (!body?.name || !body.provider) return err(400, 'name and provider required', 'bad_request');
    const e = { id: uid('env'), name: body.name, provider: body.provider, config: body.config || {}, stack: body.stack, labels: body.labels || {}, state: 'creating', busy: 'provisioning', created_at: now() };
    if (e.provider.startsWith('agentos')) e.node_id = uid('node');
    envs.push(e); envLogs[e.id] = [];
    elog(e.id, 'info', `创建环境 ${e.name} (${e.provider})`);
    broadcast('env.created', envView(e));
    setTimeout(() => { elog(e.id, 'info', e.provider === 'docker' ? `docker run -d ${e.config.image || ''}` : 'provisioning…'); }, 400);
    setTimeout(() => { if (e.provider === 'agentos-remote') { e.state = 'unknown'; e.message = '等待节点加入'; } else { e.state = 'running'; e.address = e.provider === 'docker' ? '172.17.0.' + (10 + seq % 200) : '127.0.0.1'; }
      e.busy = ''; if (e.stack) elog(e.id, 'info', `技术栈建议已记录（未自动安装） / stack suggested, not auto-installed: ${e.stack}`);
      elog(e.id, 'info', '环境已创建 / environment created'); broadcast('env.updated', envView(e)); }, 1500);
    return envView(e);
  }
  if ((m = M('GET', '/envs/:id'))) { const e = envs.find((x) => x.id === m.id); return e ? envView(e) : err(404, 'env not found', 'not_found'); }
  const E = (id) => envs.find((x) => x.id === id);
  if ((m = M('PATCH', '/envs/:id'))) { const e = E(m.id); if (!e) return err(404, 'env not found', 'not_found'); Object.assign(e, { name: body.name ?? e.name, labels: body.labels ?? e.labels, config: body.config ?? e.config, updated_at: now() }); broadcast('env.updated', envView(e)); return envView(e); }
  if ((m = M('DELETE', '/envs/:id'))) { const i = envs.findIndex((x) => x.id === m.id); if (i < 0) return err(404, 'env not found', 'not_found'); envs.splice(i, 1); broadcast('env.deleted', { id: m.id }); return null; }
  if ((m = M('POST', '/envs/:id/:act'))) {
    const e = E(m.id); if (!e) return err(404, 'env not found', 'not_found');
    if (m.act === 'start' || m.act === 'stop') {
      if (!pcaps(e.provider).includes(C.L)) return err(400, 'lifecycle not supported', 'bad_request');
      e.state = m.act === 'start' ? 'running' : 'stopped'; e.error = ''; elog(e.id, 'info', m.act === 'start' ? '环境已启动' : '环境已停止');
      for (const a of agents) if (a.node_id === e.node_id) { a.status.state = m.act === 'start' ? (a.auto_start ? 'running' : a.status.state === 'unknown' ? 'stopped' : a.status.state) : 'unknown'; broadcast('agent.status', a.status); }
      broadcast('env.updated', envView(e)); return envView(e);
    }
    if (m.act === 'test') { elog(e.id, e.state === 'error' ? 'error' : 'info', e.state === 'error' ? '连接测试失败: ' + e.error : '连接测试成功'); return e.state === 'error' ? err(502, e.error, 'node_error') : envView(e); }
    if (m.act === 'install-agentos') {
      if (!pcaps(e.provider).includes(C.I)) return err(400, 'not supported', 'bad_request');
      elog(e.id, 'info', '上传 agentos 二进制 → /opt/agentos/agentos');
      setTimeout(() => { e.node_id = uid('node'); elog(e.id, 'info', 'Agent OS 节点已连接 / node connected'); broadcast('env.updated', envView(e)); }, 1500);
      return envView(e);
    }
    if (m.act === 'join') return { token: 'join_' + Math.random().toString(36).slice(2, 12), server_url: location.origin, commands: {
      windows: `powershell -c "iwr ${location.origin}/install.ps1 -useb | iex; agentos node --server ${location.origin} --join JOINTOKEN"`,
      linux: `curl -fsSL ${location.origin}/install.sh | sh -s -- --server ${location.origin} --join JOINTOKEN`,
      macos: `curl -fsSL ${location.origin}/install.sh | sh -s -- --server ${location.origin} --join JOINTOKEN` },
      service_commands: { windows: `powershell -c "iwr ${location.origin}/download/install.ps1 -useb | iex; agentos node --server ${location.origin} --join JOINTOKEN --install-service"`,
        linux: `curl -fsSL ${location.origin}/download/install.sh | sudo sh -s -- --server ${location.origin} --join JOINTOKEN --install-service`,
        macos: `curl -fsSL ${location.origin}/download/install.sh | sudo sh -s -- --server ${location.origin} --join JOINTOKEN --install-service` } };
  }
  if ((m = M('GET', '/envs/:id/metrics'))) { const e = E(m.id); if (!e) return err(404, 'env not found', 'not_found'); const s = e.state === 'running' ? samples(e.id) : []; const since = q.get('since'); const out = since ? s.filter((x) => x.t > since) : s; return { latest: s[s.length - 1] || null, samples: out }; }
  if ((m = M('GET', '/envs/:id/logs'))) return (envLogs[m.id] || []).slice(-(+q.get('tail') || 200));
  if ((m = M('GET', '/envs/:id/files'))) { const path = q.get('path') || '/'; const l = files[path.replace(/\/$/, '') || '/']; if (!l) return err(404, 'no such file or directory', 'not_found');
    return l.map(([name, dir, size]) => ({ name, dir: !!dir, size: size || 0, mode: dir ? 0o755 : 0o644, mod_time: ago(3600 * (name.length % 30)) })); }
  if ((m = M('GET', '/envs/:id/stacks'))) { const e = E(m.id); if (!e) return err(404, '环境不存在', 'not_found'); if (!pcaps(e.provider).includes(C.X) && !e.node_id) return err(409, '该环境不支持执行命令（exec）', 'unsupported');
    const inst = envStacks[e.id] || []; return { env_id: e.id, os: { family: 'linux', id: 'ubuntu', version: '24.04', pretty: 'Ubuntu 24.04.1 LTS', arch: 'x86_64', root: false },
      stacks: stacks.map((x) => ({ id: x.id, name: x.name, installed: inst.includes(x.id), version: inst.includes(x.id) ? ({ python: '3.12.3', node: 'v22.9.0', 'claude-code': '2.0.14' }[x.id] || '1.0') : '' })), installed: inst }; }
  if ((m = M('POST', '/envs/:id/stacks/:stack/install'))) { (envStacks[m.id] = envStacks[m.id] || []).push(m.stack); const e = E(m.id); elog(m.id, 'info', `安装技术栈 ${m.stack} …`); setTimeout(() => { if (e) e.stack = m.stack; elog(m.id, 'info', `技术栈 ${m.stack} 安装完成`); if (e) broadcast('env.updated', envView(e)); }, 1200); return new R(202, { ok: true }); }
  if (M('GET', '/stacks')) return stacks;
  if (M('GET', '/nodes')) return nodes;
  if ((m = M('GET', '/nodes/:id'))) return nodes.find((n) => n.id === m.id) || err(404, 'node not found', 'not_found');
  if ((m = M('GET', '/nodes/:id/stats'))) return { latest: null, history: [] };
  if (M('GET', '/agents')) { const e = q.get('env_id') ? E(q.get('env_id')) : null; const nid = q.get('node_id') || e?.node_id; return clone(q.get('env_id') && !nid ? [] : agents.filter((a) => !nid || a.node_id === nid)); }
  if (M('POST', '/agents')) {
    if (!body?.name || !body.command || !body.node_id) return err(400, 'name, command, node_id required', 'bad_request');
    const a = ag(uid('ag'), body.node_id, body.name, body.command, body.args || [], 'stopped', { env: body.env, restart: body.restart, desc: body.description, auto: body.auto_start });
    Object.assign(a, { work_dir: body.work_dir, max_restarts: body.max_restarts, restart_delay_sec: body.restart_delay_sec }); a.status.pid = 0;
    agents.push(a); agentLogs[a.id] = []; broadcast('agent.spec', a); return clone(a);
  }
  const A = (id) => agents.find((x) => x.id === id);
  if ((m = M('GET', '/agents/:id'))) return A(m.id) ? clone(A(m.id)) : err(404, 'agent not found', 'not_found');
  if ((m = M('PUT', '/agents/:id'))) { const a = A(m.id); if (!a) return err(404, 'agent not found', 'not_found'); Object.assign(a, body, { status: a.status, id: a.id, updated_at: now() }); broadcast('agent.spec', a); return clone(a); }
  if ((m = M('DELETE', '/agents/:id'))) { const i = agents.findIndex((x) => x.id === m.id); if (i < 0) return err(404, 'agent not found', 'not_found'); agents.splice(i, 1); broadcast('agent.removed', { id: m.id }); return null; }
  if ((m = M('POST', '/agents/:id/:act'))) {
    const a = A(m.id); if (!a) return err(404, 'agent not found', 'not_found');
    if (a.status.state === 'unknown') return err(409, 'node offline', 'node_offline');
    const st = a.status;
    if (m.act === 'stop') { st.state = 'stopped'; st.pid = 0; st.exited_at = now(); pushLog(a, 'system', '进程已停止 / stopped'); }
    else { st.state = 'running'; st.pid = 1000 + Math.floor(Math.random() * 30000); st.started_at = now(); st.error = ''; if (m.act === 'restart') st.restarts++; pushLog(a, 'system', `进程已启动 / started pid=${st.pid}: ${a.command} ${(a.args || []).join(' ')}`); pushLog(a, 'stdout', 'Hello from AgentOS 👋'); }
    st.updated_at = now(); broadcast('agent.status', st); return clone(a);
  }
  if ((m = M('GET', '/agents/:id/logs'))) { const l = agentLogs[m.id] || []; const qq = (q.get('q') || '').toLowerCase(); return { lines: l.filter((x) => !qq || x.text.toLowerCase().includes(qq)).slice(-(+q.get('tail') || 200)) }; }
  if ((m = M('GET', '/agents/:id/stats'))) { const a = A(m.id); const s = a?.status.state === 'running' ? samples(m.id).map((x) => ({ time: x.t, cpu_percent: x.cpu_percent * 1.6, mem_rss: 120 * 2 ** 20 + x.cpu_percent * 4 * 2 ** 20, procs: 3 })) : []; return { latest: s[s.length - 1] || null, history: s }; }
  return err(404, 'no such endpoint', 'not_found');
}
function pushLog(a, stream, text) {
  const arr = agentLogs[a.id] = agentLogs[a.id] || [];
  const l = { agent_id: a.id, seq: arr.length + 1, time: now(), stream, text }; arr.push(l);
  for (const s of sockets) if (s.kind === 'logs' && s.target === a.id) s.recv(JSON.stringify({ type: 'agent.log', payload: l }));
}
// live host stats for Agent OS nodes (drives list mini bars + overview gauges)
nodes.forEach((n, i) => { n.host = { time: now(), cpu_percent: 12 + i * 9, cpu_count: [16, 8, 32, 12][i % 4], mem_total: [32, 16, 64, 16][i % 4] * 2 ** 30, mem_used: [11.2, 6.1, 40.5, 9.3][i % 4] * 2 ** 30, disk_total: [512, 256, 2048, 512][i % 4] * 2 ** 30, disk_used: [301, 88, 1200, 410][i % 4] * 2 ** 30, uptime_sec: 86400 * (i + 1), load1: 0.4 + i }; });
setInterval(() => {
  for (const n of nodes) {
    if (n.status !== 'online') continue;
    const hst = n.host; hst.time = now();
    hst.cpu_percent = Math.max(2, Math.min(97, hst.cpu_percent + (Math.random() - 0.5) * 12));
    hst.mem_used = Math.max(hst.mem_total * 0.15, Math.min(hst.mem_total * 0.92, hst.mem_used + (Math.random() - 0.5) * 2 ** 28));
    const ags = {};
    for (const a of agents) if (a.node_id === n.id && a.status.state === 'running') { let p = a.status.stats || { cpu_percent: 8, mem_rss: 180 * 2 ** 20, procs: 3 }; a.status.stats = p = { ...p, time: now(), cpu_percent: Math.max(0.5, Math.min(180, (p.cpu_percent || 5) + (Math.random() - 0.5) * 10)), mem_rss: Math.max(40 * 2 ** 20, (p.mem_rss || 2 ** 27) + (Math.random() - 0.5) * 2 ** 23) }; ags[a.id] = p; }
    broadcast('node.stats', { node_id: n.id, host: { ...hst }, agents: ags });
  }
}, 2000);
setInterval(() => { for (const a of agents) if (a.status.state === 'running' && Math.random() < 0.5) pushLog(a, Math.random() < 0.1 ? 'stderr' : 'stdout', LOGTXT[Math.floor(Math.random() * LOGTXT.length)]); }, 1500);

export async function fetch(path, opts = {}) {
  await new Promise((r) => setTimeout(r, 60 + Math.random() * 80));
  const method = (opts.method || 'GET').toUpperCase(), p = path.split('?')[0];
  if (/^\/envs\/[^/]+\/files\/content$/.test(p)) {
    const fp = new URLSearchParams(path.split('?')[1]).get('path');
    if (method === 'PUT') { fileContents[fp] = await new Response(opts.body).text(); const dir = fp.replace(/\/[^/]+$/, '') || '/'; (files[dir] = files[dir] || []).push([fp.split('/').pop(), 0, fileContents[fp].length]); return new Response(null, { status: 204 }); }
    return new Response(fileContents[fp] ?? `# ${fp}\n\nmock file content generated by AgentOS mock backend.\n`, { status: 200, headers: { 'Content-Type': 'application/octet-stream' } });
  }
  if (/^\/agents\/[^/]+\/logs\/download$/.test(p)) { const id = p.split('/')[2]; return new Response((agentLogs[id] || []).map((l) => `${l.time} [${l.stream}] ${l.text}`).join('\n'), { status: 200 }); }
  let body; try { body = opts.body ? JSON.parse(opts.body) : undefined; } catch { body = undefined; }
  let r = route(method, path, body);
  if (!(r instanceof R)) r = new R(r === null ? 204 : method === 'POST' && /^\/(envs|agents)$/.test(p) ? 201 : 200, r);
  return new Response(r.status === 204 ? null : JSON.stringify(r.body), { status: r.status, headers: { 'Content-Type': 'application/json' } });
}

// ---------- WebSockets ----------
class MockSocket {
  constructor(path) {
    this.path = path; this.readyState = 0; this.binaryType = 'arraybuffer';
    const p = path.split('?')[0];
    this.kind = p === '/events' ? 'events' : /\/logs\/stream$/.test(p) ? 'logs' : /\/exec$/.test(p) ? 'exec' : 'other';
    this.target = p.split('/')[2];
    setTimeout(() => {
      if (this.readyState !== 0) return;
      if (this.kind === 'other') { this.readyState = 3; this.onclose?.({ code: 1006 }); return; }
      this.readyState = 1; sockets.add(this); this.onopen?.({});
      if (this.kind === 'logs') for (const l of (agentLogs[this.target] || []).slice(-200)) this.recv(JSON.stringify({ type: 'agent.log', payload: l }));
      if (this.kind === 'exec') this.shellStart();
    }, 40);
  }
  recv(data) { if (this.readyState === 1) this.onmessage?.({ data }); }
  out(s) { this.recv(enc.encode(s).buffer); }
  close() { if (this.readyState === 3) return; this.readyState = 3; sockets.delete(this); setTimeout(() => this.onclose?.({ code: 1000 }), 0); }
  send(d) {
    if (this.kind !== 'exec') return;
    if (typeof d === 'string') { try { const m = JSON.parse(d); if (m.type === 'resize') this.size = [m.cols, m.rows]; } catch {} return; }
    const s = new TextDecoder().decode(d instanceof ArrayBuffer ? d : d.buffer ? d : new Uint8Array(d));
    for (const ch of s) {
      if (ch === '\r') { this.out('\r\n'); this.run(this.line.trim()); this.line = ''; }
      else if (ch === '\x7f') { if (this.line) { this.line = this.line.slice(0, -1); this.out('\b \b'); } }
      else if (ch === '\x03') { this.out('^C\r\n'); this.line = ''; this.prompt(); }
      else if (ch >= ' ') { this.line += ch; this.out(ch); }
    }
  }
  shellStart() {
    const e = envs.find((x) => x.id === this.target);
    this.env = e; this.line = ''; this.cwd = '/home/agent';
    this.out(`\x1b[1;36mAgentOS\x1b[0m mock shell · ${e ? e.name : this.target}\r\n输入 \x1b[33mhelp\x1b[0m 查看可用命令。\r\n\r\n`); this.prompt();
  }
  prompt() { this.out(`\x1b[1;32magent@${(this.env?.name || 'env').replace(/\s+/g, '-')}\x1b[0m:\x1b[1;34m${this.cwd}\x1b[0m$ `); }
  run(c) {
    const [cmd, ...a] = c.split(/\s+/);
    const o = (s) => this.out(s.replace(/\n/g, '\r\n') + '\r\n');
    switch (cmd) {
      case '': break;
      case 'help': o('help  ls  pwd  cd  echo  uname  date  whoami  python3  nvidia-smi  clear  exit'); break;
      case 'ls': o((files[this.cwd] || []).map(([n, d]) => d ? `\x1b[1;34m${n}\x1b[0m` : n).join('  ')); break;
      case 'pwd': o(this.cwd); break;
      case 'cd': { const t = !a[0] ? '/home/agent' : a[0].startsWith('/') ? a[0] : (this.cwd + '/' + a[0]).replace('//', '/'); if (files[t]) this.cwd = t; else o(`cd: ${a[0]}: No such file or directory`); break; }
      case 'echo': o(a.join(' ')); break;
      case 'uname': o('Linux agentos 6.8.0-45-generic #45-Ubuntu SMP x86_64 GNU/Linux'); break;
      case 'date': o(new Date().toString()); break;
      case 'whoami': o('agent'); break;
      case 'python3': o('Python 3.12.3'); break;
      case 'nvidia-smi': o('NVIDIA-SMI 560.35   Driver Version: 560.35   CUDA Version: 12.6\n|  0  RTX 4090   38C  P8  21W / 450W |  1024MiB / 24564MiB |  3%  |'); break;
      case 'clear': this.out('\x1b[2J\x1b[H'); break;
      case 'exit': this.recv(JSON.stringify({ type: 'exit', code: 0 })); this.close(); return;
      default: o(`${cmd}: command not found`);
    }
    this.prompt();
  }
}
export function socket(path) { return new MockSocket(path); }

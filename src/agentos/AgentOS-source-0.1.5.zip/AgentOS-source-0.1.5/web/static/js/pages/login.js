import { h, icon, toast } from '../util.js';
import { api, APP_MODE } from '../api.js';
import { t } from '../i18n.js';

function passwordHint() {
  // Desktop shell (AgentOS.exe): Windows stores the initial password under ProgramData;
  // the tray "显示初始密码" / server log also show it.
  const isWin = /Win/i.test(navigator.userAgent) || navigator.platform === 'Win32';
  if (APP_MODE || typeof window.agentosShellInfo === 'function') return t('login.hintDesktop');
  return isWin ? t('login.hintWin') : t('login.hint');
}

export default {
  get title() { return t('login.title'); },
  render(el) {
    const pw = h('input', { type: 'password', placeholder: t('login.password'), 'aria-label': t('login.password'), autocomplete: 'current-password' });
    const btn = h('button', { class: 'btn accent' }, t('login.submit'));
    const tip = h('div', { class: 'lf first-run', 'data-first-run': '1' }, icon('info'), h('span', {}, passwordHint()));
    // Prefer a live path from the desktop shell when available.
    if (typeof window.agentosShellInfo === 'function') {
      window.agentosShellInfo().then((i) => {
        if (!tip.isConnected || !i?.password_file) return;
        tip.querySelector('span').textContent = t('login.hintFile', { path: i.password_file });
      }).catch(() => {});
    }
    const submit = async (e) => {
      e.preventDefault();
      if (!pw.value) { pw.classList.add('invalid'); toast(t('login.empty'), true); pw.focus(); return; }
      btn.disabled = true;
      try { await api('POST', '/auth/login', { password: pw.value }); location.hash = '#/envs'; }
      catch (err) { toast(err.message, true); pw.select(); pw.classList.add('invalid'); }
      finally { btn.disabled = false; }
    };
    el.append(h('div', { class: 'login-bg' },
      h('form', { class: 'login', onsubmit: submit },
        h('div', { class: 'lb' }, h('img', { src: 'favicon.svg', alt: '' }), h('h1', {}, 'AgentOS'), h('p', { class: 'muted' }, t('app.tagline')), pw, btn),
        tip)));
    setTimeout(() => pw.focus(), 0);
  },
};

//go:build !windows && !linux

package agentoslocal

import (
	"os/exec"
	"syscall"
)

func setProcAttr(cmd *exec.Cmd) { cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true} }

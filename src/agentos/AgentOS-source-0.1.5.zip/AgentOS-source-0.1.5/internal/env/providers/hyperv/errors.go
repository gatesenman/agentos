package hyperv

import "errors"

var (
	errNotWindows   = errors.New("hyperv: 仅支持 Windows 宿主（需启用 Hyper-V）")
	errNotAvailable = errors.New("hyperv: Hyper-V 不可用（未启用或无权限）")
	errNoISO        = errors.New("hyperv: 请指定 iso_path（Windows 评估版 ISO 需从微软评估中心自行下载）")
)

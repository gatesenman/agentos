package hyperv

import (
	"bufio"
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
	"os"
	"strings"
)

// isoReadFile reads a file from an ISO 9660 image using the primary volume
// descriptor (names compared case-insensitively, ";1" and trailing "." ignored).
func isoReadFile(isoPath, name string) ([]byte, error) {
	f, err := os.Open(isoPath)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	pvd := make([]byte, isoSector)
	if _, err := f.ReadAt(pvd, 16*isoSector); err != nil {
		return nil, err
	}
	if pvd[0] != 1 || string(pvd[1:6]) != "CD001" {
		return nil, fmt.Errorf("not an ISO 9660 image")
	}
	lba := binary.LittleEndian.Uint32(pvd[156+2:])
	size := binary.LittleEndian.Uint32(pvd[156+10:])
	parts := strings.Split(strings.Trim(name, "/"), "/")
	for i, part := range parts {
		dir := make([]byte, size)
		if _, err := f.ReadAt(dir, int64(lba)*isoSector); err != nil && err != io.EOF {
			return nil, err
		}
		found := false
		for off := 0; off < len(dir); {
			l := int(dir[off])
			if l == 0 {
				off = (off/isoSector + 1) * isoSector
				continue
			}
			if off+l > len(dir) || l < 34 {
				break
			}
			r := dir[off : off+l]
			n := string(r[33 : 33+int(r[32])])
			n = strings.TrimSuffix(strings.SplitN(n, ";", 2)[0], ".")
			if strings.EqualFold(n, part) {
				lba = binary.LittleEndian.Uint32(r[2:])
				size = binary.LittleEndian.Uint32(r[10:])
				isDir := r[25]&2 != 0
				if (i < len(parts)-1) != isDir {
					return nil, fmt.Errorf("%s: unexpected type", part)
				}
				found = true
				break
			}
			off += l
		}
		if !found {
			return nil, fmt.Errorf("%s not found in ISO", name)
		}
	}
	if size > 16<<20 {
		return nil, fmt.Errorf("%s too large", name)
	}
	out := make([]byte, size)
	_, err = f.ReadAt(out, int64(lba)*isoSector)
	if err == io.EOF {
		err = nil
	}
	return out, err
}

// grubBootFiles returns kernel/initrd of the first menuentry in a grub.cfg.
func grubBootFiles(cfg []byte) (kernel, initrd string) {
	sc := bufio.NewScanner(bytes.NewReader(cfg))
	in := false
	for sc.Scan() {
		l := strings.TrimSpace(sc.Text())
		if strings.HasPrefix(l, "menuentry ") {
			in = true
			continue
		}
		if !in {
			continue
		}
		fs := strings.Fields(l)
		if len(fs) >= 2 && (fs[0] == "linux" || fs[0] == "linuxefi") && kernel == "" {
			kernel = fs[1]
		}
		if len(fs) >= 2 && (fs[0] == "initrd" || fs[0] == "initrdefi") && initrd == "" {
			initrd = fs[1]
		}
		if l == "}" {
			break
		}
	}
	return
}

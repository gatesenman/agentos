# agentos-desktop image

Used by the `docker` provider when `desktop: true` and no `image` is set.

    docker build -t localhost/agentos-desktop:latest internal/env/providers/docker/images/desktop

* Xvfb display `:0` (`GEOMETRY` env, default 1280x800x24), fluxbox, xterm, CJK fonts.
* x11vnc on port 5900 without password. The provider publishes it on `127.0.0.1` only
  (local daemon) and the console relays it through `/envs/{id}/desktop?kind=vnc`.
* Custom desktop images work too: set `image` + `desktop: true`; the image must run its
  own VNC server on 5900 (the provider keeps the image's ENTRYPOINT/CMD in desktop mode).

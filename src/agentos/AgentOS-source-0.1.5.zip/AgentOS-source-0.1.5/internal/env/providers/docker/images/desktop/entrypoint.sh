#!/bin/sh
# Starts a virtual X display, a window manager and a VNC server on :5900, then
# stays in the foreground (restarting x11vnc if it dies) until SIGTERM.
set -u
trap 'kill $(jobs -p) 2>/dev/null; exit 0' TERM INT
rm -f /tmp/.X0-lock
Xvfb "$DISPLAY" -screen 0 "$GEOMETRY" -nolisten tcp &
for i in $(seq 1 50); do [ -e /tmp/.X11-unix/X0 ] && break; sleep 0.1; done
fluxbox >/tmp/fluxbox.log 2>&1 &
(sleep 1; xterm -geometry 100x28+60+60 -title "AgentOS $(hostname)" >/tmp/xterm.log 2>&1) &
while :; do
  x11vnc -display "$DISPLAY" -rfbport 5900 -forever -shared -nopw -quiet -noxdamage >/tmp/x11vnc.log 2>&1 &
  wait $!
  sleep 1
done

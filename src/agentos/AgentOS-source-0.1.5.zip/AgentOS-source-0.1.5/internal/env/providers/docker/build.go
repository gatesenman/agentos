package docker

import (
	"archive/tar"
	"bytes"
	"context"
	"embed"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"net/url"
	"strings"

	"github.com/agentos/agentos/internal/env"
)

// desktopContext is the build context of DesktopImage (Dockerfile +
// entrypoint), embedded so the server can build the image on first use.
//
//go:embed images/desktop
var desktopContext embed.FS

func desktopContextTar() ([]byte, error) {
	var buf bytes.Buffer
	tw := tar.NewWriter(&buf)
	sub, err := fs.Sub(desktopContext, "images/desktop")
	if err != nil {
		return nil, err
	}
	err = fs.WalkDir(sub, ".", func(p string, d fs.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}
		b, err := fs.ReadFile(sub, p)
		if err != nil {
			return err
		}
		mode := int64(0o644)
		if strings.HasSuffix(p, ".sh") {
			mode = 0o755
		}
		if err := tw.WriteHeader(&tar.Header{Name: p, Mode: mode, Size: int64(len(b))}); err != nil {
			return err
		}
		_, err = tw.Write(b)
		return err
	})
	if err != nil {
		return nil, err
	}
	if err := tw.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// buildDesktopImage builds DesktopImage from the embedded context via the
// Docker API (POST /build), logging the build steps to the env log.
func buildDesktopImage(ctx context.Context, cl *client) error {
	ctxTar, err := desktopContextTar()
	if err != nil {
		return err
	}
	env.Logf(ctx, "info", "构建桌面镜像 / building desktop image %s (首次需几分钟 / first build takes a few minutes)", DesktopImage)
	q := url.Values{"t": {DesktopImage}, "rm": {"1"}, "forcerm": {"1"}}
	resp, err := cl.do(ctx, "POST", "/build", q, bytes.NewReader(ctxTar), "application/x-tar")
	if err != nil {
		return fmt.Errorf("构建桌面镜像失败 / build %s: %w", DesktopImage, err)
	}
	defer resp.Body.Close()
	dec := json.NewDecoder(resp.Body)
	for {
		var m struct {
			Stream string `json:"stream"`
			Error  string `json:"error"`
		}
		if err := dec.Decode(&m); err != nil {
			if err == io.EOF {
				break
			}
			return fmt.Errorf("构建桌面镜像失败 / build %s: %w", DesktopImage, err)
		}
		if m.Error != "" {
			return fmt.Errorf("构建桌面镜像失败 / build %s: %s", DesktopImage, m.Error)
		}
		if s := strings.TrimSpace(m.Stream); strings.HasPrefix(s, "Step ") || strings.HasPrefix(s, "Successfully") {
			env.Logf(ctx, "info", "%s", s)
		}
	}
	if err := cl.json(ctx, "GET", "/images/"+DesktopImage+"/json", nil, nil, nil); err != nil {
		return fmt.Errorf("构建桌面镜像失败 / build %s: image missing after build: %w", DesktopImage, err)
	}
	env.Logf(ctx, "info", "桌面镜像就绪 / desktop image ready: %s", DesktopImage)
	return nil
}
